(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g=(g.de||(g.de = {}));g=(g.appwerft||(g.appwerft = {}));g.googeotools = f()}})(function(){var define,module,exports;return (function e(t,n,r){function o(i,u){if(!n[i]){if(!t[i]){var a=typeof require=="function"&&require;if(!u&&a)return a.length===2?a(i,!0):a(i);if(s&&s.length===2)return s(i,!0);if(s)return s(i);var f=new Error("Cannot find module '"+i+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[i]={exports:{}};t[i][0].call(l.exports,function(e){var n=t[i][1][e];return o(n?n:e)},l,l.exports,e,t,n,r)}return n[i].exports}var i=Array.prototype.slice;Function.prototype.bind||Object.defineProperty(Function.prototype,"bind",{enumerable:!1,configurable:!0,writable:!0,value:function(e){function r(){return t.apply(this instanceof r&&e?this:e,n.concat(i.call(arguments)))}if(typeof this!="function")throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");var t=this,n=i.call(arguments,1);return r.prototype=Object.create(t.prototype),r.prototype.contructor=r,r}});var s=typeof require=="function"&&require;for(var u=0;u<r.length;u++)o(r[u]);return o})({1:[function(require,module,exports){
var Promises = require('org.favo.promise');

exports.getPositionByIP = function(_ip) {
	var ip = _ip ? _ip : Ti.Platform.getAddress( );
	var promise = Promise.defer();
	var xhr = Ti.UI.createHTTPClient({
		onload : function() {
			promise.resolve(JSON.parse(this.responseText));
		},
		onerror : function(_e) {
			promise.reject(_e);
		}
	});
	xhr.open('GET','http://freegeoip.net/json/'+ip);
	xhr.send();
	return promise;
};

exports.getRegionOfCountry = function(_country) {
	var promise = Promise.defer();
	var country = _country || 'Deutschland';
	var xhr = Ti.UI.createHTTPClient({
		onload : function() {
			try {
				var json = JSON.parse(this.responseText);
				if (json.status == 'OK') {
					var result = json.results[0].geometry;
					var region = {
						latitude : result.location.lat,
						longitude : result.location.lng,
						latitudeDelta : Math.abs(result.viewport.northeast.lat - result.viewport.southwest.lat),
						longitudeDelta : Math.abs(result.viewport.northeast.lng - result.viewport.southwest.lng)
					};
					promise.resolve(region);
				}
			} catch (E) {
				promise.reject(E);
			}
		},
		onerror : function() {
			promise.reject(_e);
		}
	});
	xhr.open('GET', 'http://maps.googleapis.com/maps/api/geocode/json?address=' + country + '&sensor=false');
	xhr.send();
};

exports.getRoute = function() {
	var promise = Promise.defer();
	/* helperfunction to decode googles polyline:*/
	var decodeLine = function(encoded) {
		var len = encoded.length;
		var index = 0;
		var array = [];
		var lat = 0;
		var lng = 0;
		while (index < len) {
			var b;
			var shift = 0;
			var result = 0;
			do {
				b = encoded.charCodeAt(index++) - 63;
				result |= (b & 0x1f) << shift;
				shift += 5;
			} while (b >= 0x20);
			var dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
			lat += dlat;

			shift = 0;
			result = 0;
			do {
				b = encoded.charCodeAt(index++) - 63;
				result |= (b & 0x1f) << shift;
				shift += 5;
			} while (b >= 0x20);
			var dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
			lng += dlng;
			array.push([lat * 1e-5, lng * 1e-5]);
		}
		var points = [];
		for (var i = 0; i < array.length; i++) {
			points.push({
				"latitude" : array[i][0],
				"longitude" : array[i][1]
			});
		}
		return points;
	};
	var source = arguments[0] || {};
	var destination = arguments[0] || {};
	source.φ = Array.isArray(source) ? source[0]: source.lat || source.latitude ;
	source.λ = Array.isArray(source) ? source[1] : source.lng || source.lon || source.longitude;
	destination.φ = Array.isArray(destination) ? destination[0]: destination.lat || destination.latitude ;
	destination.λ = Array.isArray(destination) ? destination[1] : destination.lng || destination.lon || destination.longitude;
		
};

},{"org.favo.promise":undefined}]},{},[1])(1)
});